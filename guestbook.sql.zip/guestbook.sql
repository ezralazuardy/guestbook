-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 04 Jul 2019 pada 04.29
-- Versi server: 10.1.38-MariaDB
-- Versi PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `guestbook`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `guest_lists`
--

CREATE TABLE `guest_lists` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `agency` varchar(200) NOT NULL,
  `address` text,
  `telephone` varchar(20) NOT NULL,
  `gender` char(1) NOT NULL DEFAULT 'l',
  `necessity` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `guest_lists`
--

INSERT INTO `guest_lists` (`id`, `name`, `email`, `agency`, `address`, `telephone`, `gender`, `necessity`, `created_at`, `deleted_at`) VALUES
(1, 'Ezra Lazuardy Wijaya', 'ezralucio@gmail.com', 'SMK Negeri 7 Semarang', 'Semarang', 'l', 'l', 'Keperluan A', '2019-07-04 08:51:21', NULL),
(2, 'Mamang Garox', 'samlekom@mamang.com', 'Zeeber', 'Purwokerto', 'p', 'p', 'Keperluan C', '2019-07-04 08:52:34', NULL),
(3, 'Almira Rosa Humaira', 'humhum@gmail.com', 'SMA Negeri 1 Semarang', 'Semarang', 'p', 'p', 'Keperluan B', '2019-07-04 09:03:43', NULL),
(4, 'Pak 3', '3@email.com', 'SmK negErI TuJUh seMaraNg', 'Korea', 'l', 'l', 'Keperluan C', '2019-07-04 09:05:19', NULL);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `guest_lists`
--
ALTER TABLE `guest_lists`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `guest_lists`
--
ALTER TABLE `guest_lists`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
